import tkinter
import tkinter.ttk as ttk
from PIL import Image, ImageTk
from pylab import *
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import cv2
import os
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import xlwings as xw
import plotly.graph_objects as go
import pandas as pd



 
class App:
    def __init__(self, window,window_title="Final project", imgPath="gaussian.jpg"):
        self.window = window
        self.window.minsize(width=1300,height=800)
        self.window.maxsize(width=1300,height=800)
        self.window.title = window_title
        
        
        #load image and convert color order
        self.imageCV = cv2.imread(imgPath,0)
        self.imageCV  = cv2.resize(self.imageCV, (750, 750)) 
        
        #Create notebook for tabs
        self.tab = ttk.Notebook(window, width=750, height=750)
        self.tab.grid(row=0, column=2)
        
        #tab1
        self.page1 = ttk.Frame(self.tab)
        self.tab.add(self.page1, text="Smoothing")
        #tab2
        self.page2 = ttk.Frame(self.tab)
        self.tab.add(self.page2, text="Edge Detection")
        
        self.page3 = ttk.Frame(self.tab)
        self.tab.add(self.page3, text="2d to 3d")
        
        self.page4 = ttk.Frame(self.tab)
        self.tab.add(self.page4, text="Sobels")
    
        # Create a canvas that can fit the above image
        self.canvas = tkinter.Canvas(window, width=750, height=750)
        self.canvas.grid(row=0, column=0, sticky=tkinter.W+tkinter.N)

        # Use PIL (Pillow) to convert the NumPy ndarray to a PhotoImage
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))

        # Add a PhotoImage to the Canvas
        self.canvas.create_image(0, 0, image=self.canvasImage, anchor=tkinter.NW)
        
        #Listbox
        self.imageOptions = tkinter.Listbox(window, height =37)
        self.imageOptions.grid(row=0, column=1, sticky=tkinter.W+tkinter.N)
        
        #populate listbox        
        path=os.getcwd()
        self.imageList = [f for f in os.listdir(path) if f.endswith('.jpg')]
        
        arrLen = len(self.imageList)
        for i in range(0, arrLen):
            self.imageOptions.insert(tkinter.END, self.imageList[i])
            i+=1

        self.imageOptions.bind("<<ListboxSelect>>", lambda x: self.onClick())                
        
        #Blur buttons in page 1
        self.AVblurButton=tkinter.Button(self.page1, text="Average Blur", command = self.blur)
        self.AVblurButton.grid(row=0, column=0,sticky=tkinter.W)
        
        self.GblurButton = tkinter.Button(self.page1, text="Gaussian Blur", command=self.gaussianBlur)
        self.GblurButton.grid(row=0, column=1,sticky=tkinter.W)
        
        self.MblurButton = tkinter.Button(self.page1, text="Median Blur", command=self.medianBlur)
        self.MblurButton.grid(row=0, column=2,sticky=tkinter.W)
        
        self.BFblurButton = tkinter.Button(self.page1, text="Bilateral Blur", command=self.bilateralFilter)
        self.BFblurButton.grid(row=0, column=3,sticky=tkinter.W)
        
        #Edge detection filters
        self.lapacianB=tkinter.Button(self.page2, text="laplacian", command = self.laplacianED)
        self.lapacianB.grid(row=0, column=0,sticky=tkinter.W)
        
        self.cannyB = tkinter.Button(self.page2, text="Canny", command = self.cannyED)
        self.cannyB.grid(row=0, column=1,sticky=tkinter.W)
        
        self.adaptiveMeanB=tkinter.Button(self.page2, text="Adaptive Mean Threshold", command = self.adaptiveMThreshhold)
        self.adaptiveMeanB.grid(row=0, column=2,sticky=tkinter.W)

        self.adaptiveAB =tkinter.Button(self.page2, text="Adap. Gaussian GThreshold", command = self.adaptiveGThreshhold)
        self.adaptiveAB.grid(row=0, column=3,sticky=tkinter.W+ tkinter.N)
        
        #2d to 3d 
        self.matPlotLib2D3DB=tkinter.Button(self.page3, text="2d to 3d with matplotlib", command = self.MPL3D)
        self.matPlotLib2D3DB.grid(row=0, column=0,sticky=tkinter.W)
        
        self.mayaviButton=tkinter.Button(self.page3, text="2d to 3d with plotly", command = self.plotly3D)
        self.mayaviButton.grid(row=0, column=1,sticky=tkinter.W)
        
        self.excelExport=tkinter.Button(self.page3, text="Export MPL to excel", command = self.toExcel)
        self.excelExport.grid(row=1, column=0,sticky=tkinter.W + tkinter.N)
        
        self.sobelXB=tkinter.Button(self.page4, text="SobelX", command = self.sobelX)
        self.sobelXB.grid(row=0, column=0,sticky=tkinter.W)
        
        self.sobelYB=tkinter.Button(self.page4, text="SobelY", command = self.sobelY)
        self.sobelYB.grid(row=0, column=1,sticky=tkinter.W + tkinter.N)
        
        
        
        
        self.window.mainloop() 
            
    def onClick(self):
    
        items = self.imageOptions.curselection()
        items = [self.imageList[int(item)] for item in items]          
        self.listItem = ''.join(items)
        print(self.listItem)
        
        self.imageCV = cv2.imread(self.listItem, 0)
        self.imageCV  = cv2.resize(self.imageCV, (750, 750)) 
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
            
            #self.canvas.delete("all")
        
    def blur(self):
        self.imageCV = cv2.blur(self.imageCV, (5,5))
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image=self.canvasImage, anchor=tkinter.NW)
   
    def gaussianBlur(self):
        self.imageCV = cv2.GaussianBlur(self.imageCV, (5,5),cv2.BORDER_DEFAULT)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)

    def medianBlur(self):
        self.imageCV =  cv2.medianBlur(self.imageCV,5)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
        
    def bilateralFilter(self):
        self.imageCV =  cv2.bilateralFilter(self.imageCV,9,75,75)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
        
    def laplacianED(self):

        self.imageCV = cv2.Laplacian(self.imageCV,cv2.CV_64F)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
        
    def cannyED(self):

        self.imageCV = cv2.Canny(self.imageCV,100,200)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
        
    def adaptiveMThreshhold(self):

        self.imageCV = cv2.adaptiveThreshold(self.imageCV,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,2)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
        
    def adaptiveGThreshhold(self):
 
        self.imageCV = cv2.adaptiveThreshold(self.imageCV ,255,cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY,11,2)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
        
        
        
    def MPL3D(self):

         #image needs to be scaled otherwise it takes way too long to load
        scale_percent = 10 # percent of original size
        width = int(self.imageCV.shape[1] * scale_percent / 100)
        height = int(self.imageCV.shape[0] * scale_percent / 100)
        dim = (width, height)
        # resize image
        resized = cv2.resize(self.imageCV, dim, interpolation = cv2.INTER_AREA)
        
        xvalue, yvalue = np.mgrid[0:resized.shape[0], 0:resized.shape[1]]
        
        
        fig = plt.figure()
        ax = fig.gca(projection='3d')
        ax.plot_surface(xvalue, yvalue, resized ,rstride=1, cstride=1, cmap=plt.cm.winter,
                linewidth=0)

        # show it
        plt.show()

    def plotly3D(self):
        
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
           
        #image needs to be scaled otherwise it takes way too long to load
        scaleImage = 95 # percent of original size
        width = int(self.imageCV.shape[1] * scaleImage / 100)
        height = int(self.imageCV.shape[0] * scaleImage / 100)
        dim = (width, height)
        # resize image
        resized = cv2.resize(self.imageCV, dim, interpolation = cv2.INTER_AREA)
        
        xvalue, yvalue = np.mgrid[0:resized.shape[0], 0:resized.shape[1]]
        fig = go.Figure(data=[go.Surface(z=resized, x=xvalue, y=yvalue)])

        fig.update_layout(title='Mt Bruno Elevation', autosize=False,
                          width=500, height=500,
                          margin=dict(l=65, r=50, b=65, t=90))
                          
        fig.show()
        
    def sobelX(self):
        self.imageCV = cv2.Sobel(self.imageCV,cv2.CV_64F,1,0,ksize=5)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
    
    def sobelY(self):
        self.imageCV = cv2.Sobel(self.imageCV,cv2.CV_64F,0,1,ksize=5)
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
    
    def toExcel(self):
        
        wb = xw.Book() 
        sht = wb.sheets['Sheet1']
        
        self.canvasImage = ImageTk.PhotoImage(image = Image.fromarray(self.imageCV))
        self.canvas.create_image(0, 0, image= self.canvasImage, anchor=tkinter.NW)
           
        #image needs to be scaled otherwise it takes way too long to load
        scaleImage = 95 # percent of original size
        width = int(self.imageCV.shape[1] * scaleImage / 100)
        height = int(self.imageCV.shape[0] * scaleImage / 100)
        dim = (width, height)
        # resize image
        resized = cv2.resize(self.imageCV, dim, interpolation = cv2.INTER_AREA)
        
        xvalue, yvalue = np.mgrid[0:resized.shape[0], 0:resized.shape[1]]
        
        sizeX = len(xvalue)
        sizeY = len(yvalue)
        sizeZ = len(resized)
        
        print(xvalue[10])
        
        for j in sizeX:
            sht.range(("A1")).value = xvalue[j]
            j+=1
            
        print(sizeX)
        print(sizeY)
        print(sizeZ)
        
        
                                        
App(tkinter.Tk())